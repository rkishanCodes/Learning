import { usersData } from './usersData.js'

console.log(usersData);


console.log('hi');



console.log('jjeelke');
