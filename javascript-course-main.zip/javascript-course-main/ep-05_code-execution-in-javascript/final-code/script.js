debugger
console.log(firstName)

var firstName = 'Akash'
let lastName = 'Singh'
let age = 15
const yearOfBirth = 1999

// let userIntro = 'Hi, my name is ' + firstName + ' ' + lastName