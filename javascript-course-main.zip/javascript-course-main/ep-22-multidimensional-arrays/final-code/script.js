const nameAndNumberList = [
  ['Adarsh', 75],
  ['Akash', 90],
  ['Anurag', 9],
]

const ticTacToe = [
    ['X', null, null],
    [null, null, 'O'],
    ['O', null, 'X']
]
