console.log('Program Start')


for(let i = 0; i <= 10; i++) {
    if(i % 2 === 0) {
        console.log(i); 
    }
}

console.log('Program Ended')
