debugger

// sayHi()

// const username = 'Anurag'
// const userAge = 25

// function sayHi() {
//     const a = 14
//     const b = 12
//     add(7, 9)
// }

// function add(x, y) {
//     kuchhBhi()
//     return x + y
// }

// function kuchhBhi() {
//     console.log('Kuchh bhi');
// }

function introduceMe() {
    console.log('Hi, My name is Anurag.');
    introduceMe()
}

introduceMe()

console.log('Program Ended');