const user = {
  firstName: "Anurag",
  lastName: "Singh",
  age: 25,
}