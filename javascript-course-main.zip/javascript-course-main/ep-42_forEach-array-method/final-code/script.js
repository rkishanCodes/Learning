const fruits = ['banana', 'apple', 'peach', 'mango', 'grapes']
