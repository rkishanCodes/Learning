const fruits = ['banana', 'apple', 'peach', 'mango', 'grapes']


// for(const fruit of fruits) {
//     console.log(fruit);
// }


// fruits.forEach(function(fruit) {
//     console.log(fruit);
// })

// fruits.forEach((fruit) => {
//     console.log(fruit);
// })

// function abc(el) {
//     console.log(el);
// }

// fruits.forEach(abc)