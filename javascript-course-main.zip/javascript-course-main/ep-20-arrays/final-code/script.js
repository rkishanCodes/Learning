const username = 'Anurag Singh'

const fruitsCollection = ['Apple', 'Banana', 'Grapes', 'Dates']

const newObject = {}
const newArray = []
