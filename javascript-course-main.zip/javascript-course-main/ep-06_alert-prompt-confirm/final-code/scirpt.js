// const alertResult = alert("Are you sure?")
// const isConfirmed = confirm("Would you like to proceed?")
const userInput = prompt("Please enter your name.........................")
console.log(userInput)