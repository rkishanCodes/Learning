function sayHi() {
  document.body.children[4].src =
    'https://cdn.pixabay.com/photo/2014/02/27/16/10/flowers-276014__340.jpg'
}
