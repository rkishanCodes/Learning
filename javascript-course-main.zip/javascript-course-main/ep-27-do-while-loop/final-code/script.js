console.log('Program Start')

// debugger
// let i = 0
// while (i < 5) {
//   console.log(i)
//   i++
// }

// for(let i = 0; i < 5; i++) { 
//     console.log(i);
// }

let i = 0 
do {
    console.log(i);
    i++
} while (i < 5)

console.log('Program Ended')
