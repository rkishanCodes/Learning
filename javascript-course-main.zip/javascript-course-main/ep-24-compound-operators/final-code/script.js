const username = 'Anurag'

let num = 5

// debugger
// num = num + 5
// num = num + 5
// num = num + 5
// num = num + 5

// num += 5
// num += 5
// num += 5
// num += 5

// num = num * 2
// num = num * 2
// num = num * 2

// num *= 2
// num *= 2
// num *= 2

// const newNum = ++num
// const newNum = --num

// const newNum = num++
// const newNum = num--

// num = num + 1
// num += 1

num++