// debugger

console.log(a)

var a = 'Anurag'

hi()


// Function Definition
// Function Declaration
function hi() {
    console.log('Hello');
}

// Function Definition
// Function Expression
var sayHi = function() {    //anonymous function
    console.log('Hiii');
}

// IIFE


sayHi()