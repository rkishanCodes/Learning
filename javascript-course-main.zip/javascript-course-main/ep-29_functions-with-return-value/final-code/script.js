function addTwoNumbers(a, b) {
debugger

    return a + b
}

// const result = addTwoNumbers(56, 6)

// console.log(result);