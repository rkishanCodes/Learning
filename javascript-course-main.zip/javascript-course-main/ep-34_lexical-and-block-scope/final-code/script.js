'use strict'

const username = 'Anurag'
let userAge = 25
var a = 50

// function add() {
//   const username = 'Akash'
//   const x = 5
//   const y = 8
//   console.log(x + y)
//   console.log(username)
// }

function subtract() {
  const x = 15
  const y = 18
  const z = 28
  // console.log(x - y)
  // console.log(username)

  function child() {
  // debugger

    const childName = 'Golu'
    // console.log(childName);
    // console.log(x,z);

    if(true){
      let num1 = 78
      var num2 = 987
      console.log(num1);
      console.log(num2);
    }
    console.log(num2);

    function grandChild() {
      const grandChildName = 'Molu'
      // console.log(grandChildName);
    }
    grandChild()
  }


  child()

}

// add()
subtract()

console.log('Program Ended')
