const container = document.querySelector(".container")
const card = document.querySelector('.card')