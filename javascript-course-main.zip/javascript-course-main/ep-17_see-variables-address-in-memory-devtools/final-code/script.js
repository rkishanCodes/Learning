const firstName = 'Akash'
const lastName = 'Singh'
const userAge = 15
const birthYear = 2000
const isGraduate = false
const hasJob = true