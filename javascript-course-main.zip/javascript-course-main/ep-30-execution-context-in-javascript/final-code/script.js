debugger

sayHi()

const username = 'Anurag'
const userAge = 25

function sayHi() {
    const a = 14
    const b = 12
    add(7, 9)
}

function add(x, y) {
    kuchhBhi()
    return x + y
}

function kuchhBhi() {
    console.log('Kuchh bhi');
}

console.log('Program Ended');