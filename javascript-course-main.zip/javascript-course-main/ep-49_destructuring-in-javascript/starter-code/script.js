const colors = ['red', 'green', 'yellow', 'pink', 'black']

const user = {
  name: 'Anurag',
  age: 25,
  address: {
    city: 'Bangalore',
    state: 'Karnataka',
  },
}
