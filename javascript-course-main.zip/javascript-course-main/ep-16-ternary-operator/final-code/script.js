const username = 5 > 2 ? 'Anurag' : 'Procodrr'

// const gender = 'F'

// debugger
// const userMessage = `${gender.toLocaleLowerCase() === 'f' ? 'She' : 'He'} is a college student.`

// console.log(userMessage);

const result = null ? 'Anurag' : '' ? '12' : 0

console.log(result)
