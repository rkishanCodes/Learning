console.log('Hi-1');

function hello() {
    console.log('Hello World!');
}

for(let i = 1; i <=4; i++){
    console.log(i);
}

hello()
setTimeout(hello, 0)

console.log('Hi-2');