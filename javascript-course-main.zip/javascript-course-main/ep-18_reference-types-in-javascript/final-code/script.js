const myName = 'Anurag'

const username1 = ''
const username2 = ''

const user1 = {
    firstName: 'Akash'
}


// const user2 = {
//     firstName: 'Adarsh',
//     'last-Name': 'Singh',
//     Anurag: 'Developer'
// }

// console.log(user2.firstName);
// console.log(user2["last-Name"]);
// console.log(user2[myName]);
// console.log(user2["first" + "Name"]);

const user2 = {
    firstName: 'Adarsh',
    lastName: 'Singh',
    pata: {
        city: 'Bangalore',
        pinCode: 876876,
        state: 'Karnataka',
        moreDetails: {
            population: 9798897897,
            area: '787 sq km',
        }
    }
}

// user2.age = 26
// user2["is-student"] = true