const fruits = ['Mango', 'Apple', 'Orange']
