const userAge1 = 21
const userAge2 = 24