// const h1 = document.querySelector('h1')
// const input = document.querySelector('input')

// window.addEventListener('keypress', (e) => {
//     console.log('Code: ',e.code);
//     console.log('Value: ', e.key);
// })

// window.addEventListener('keyup', (e) => {
//     console.log('Code: ',e.code);
//     console.log('Value: ', e.key);
// })

window.addEventListener('keydown', (e) => {
    console.log('Code: ',e.code);
    console.log('Value: ', e.key);
})