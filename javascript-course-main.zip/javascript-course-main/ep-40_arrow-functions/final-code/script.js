// // Function Declaration

// function square(num){
//     return num * num
// } 

// // Function Expression

// const square = function(num) {
//     return num * num
// }

// // Arrow Function Expression

// const square = (num) => {
//     return num * num
// }

const square = num => num * num
const add = (a, b) => a + b

const random = () => (
    Math.floor(Math.random() * 10) + 1
)

// setTimeout(() => {
//     console.log('hiii');
// }, 2000)

