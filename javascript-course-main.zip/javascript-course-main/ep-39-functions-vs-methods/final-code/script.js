const maths = {
  E: 2.718281828459045,
  add: function (a, b) {
    return a + b
  },
  square: function(num) {
     return num * num;
  },
  subtract(a, b) {
    return a - b
  },
  cube(num) {
    return num ** 3
  }
}

