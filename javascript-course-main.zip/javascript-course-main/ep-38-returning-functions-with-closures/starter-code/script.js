const a = 4
const b = 6

function add() {
  console.log(a + b)
}